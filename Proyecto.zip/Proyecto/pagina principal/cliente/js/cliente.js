"use strict";

const botonCitas = document.getElementById('solicitudCitas');
const botonPresupuesto = document.getElementById('medirPresupuesto');

botonCitas.addEventListener('click', (e) =>{
    e.preventDefault();

    window.open("solicitarCitas.html", "_self");
});

botonPresupuesto.addEventListener('click', (e) =>{
    e.preventDefault();

    window.open("medirPresupuestos.html", "_self");
});


